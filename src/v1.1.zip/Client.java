import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class Client {
    private static final Logger logger = LogManager.getLogger(Client.class);
    public static void main(String[] args) throws Exception {
        System.out.println("[" + System.currentTimeMillis() + "] " + "Please specify which server you'd like to connect. Port:");
        Scanner sc = new Scanner(System.in);
        int port = -1;
        while (true) {
            port = Integer.parseInt(sc.nextLine());
            if (port < 0) {
                System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter a correct port number.");
            }
            else {
                System.out.println("[" + System.currentTimeMillis() + "] " + String.format("Connecting to server: %d", port));
                break;
            }
        }

        String hostname = "127.0.0.1";
        Registry registry = LocateRegistry.getRegistry(hostname, port);
        RemoteUserInterface stub = (RemoteUserInterface) registry.lookup(String.format("PROJPEDIA_server%d", port));
        String cmd = null;
        String username = null, password = null;

        // User credential part
//        System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter your need:\n" +
//                "\t1. Sign up for a new account;\n" +
//                "\t2. Log in with existing account and password;");
//        while (true) {
//
//            cmd = sc.nextLine();
//            if (cmd.equals("1")) {
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Register a new account...");
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Please provide your account username:");
//                username = sc.nextLine();
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Please provide your account password:");
//                password = sc.nextLine();
//                String response = stub.signup(username, password);
//                if (response.equals("Sign up successfully")) {
//                    System.out.println("[" + System.currentTimeMillis() + "] " + response + "...loggin in...");
//                    stub.login(username, password);
//                    break;
//                }
//                else if (response.equals("User already exit. No need for register")) {
//                    System.out.println("[" + System.currentTimeMillis() + "] " + "User already exit. No need for register. Please enter 2 to login.");
//                }
//            }
//            else if (cmd.equals("2")) {
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Log in...");
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Please provide your account username:");
//                username = sc.nextLine();
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Please provide your account password:");
//                password = sc.nextLine();
//                String response = stub.login(username, password);
//                if (response.equals("Already login as " + username + ". Please logout first")) {
//                    System.out.println("[" + System.currentTimeMillis() + "] " + "Already logged in as " + username + ". Please logout first");
//                }
//                else if (response.equals("Login successfully")) {
//                    System.out.println("[" + System.currentTimeMillis() + "] " + "Login successfully!");
//                }
//                else {
//                    System.out.println("[" + System.currentTimeMillis() + "] " + "Wrong username or password. Please enter 2 and try again");
//                }
//                break;
//            }
//            else {
//                System.out.println("[" + System.currentTimeMillis() + "] " + "Please choose from the options (1/2)");
//            }
//        }

        System.out.println("[" + System.currentTimeMillis() + "] " + "Welcome to PROJPEDIA, " + username + "!");
        System.out.println("[" + System.currentTimeMillis() + "] " + username + ", what do you want to do today?");

        while (true) {
            System.out.println("[" + System.currentTimeMillis() + "] " +
                    "\t1. Read entries we have" +
                    "\n\t2. Edit existing entry" +
                    "\n\t3. Delete existing entry" +
                    "\n\t4. Add new entry");
            cmd = sc.nextLine();
            if (cmd.equals("1")) {
                System.out.println("[" + System.currentTimeMillis() + "] " + "Below are all entries we have now:");
                ConcurrentHashMap.KeySetView<String, String> keySet = stub.getEntryKeyList();
                int index = 1;
                StringBuilder builder = new StringBuilder();
                for (String key : keySet) {
                    builder.append("\t" + index + ". " + key);
                }
                if (builder.toString().length() == 0) {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "The current database is empty.");
                    continue;
                }
                while (true) {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter the entry name: ");
                    String entryKey = sc.nextLine();
                    if (entryKey.equals("w") || entryKey.equals("W")) break;
                    System.out.println("[" + System.currentTimeMillis() + "] " + "You are requesting to read entry: " + entryKey);
                    String response = stub.get(entryKey);
                    if (response.equals("none")) {
                        // No corresponding entry
                        System.out.println("[" + System.currentTimeMillis() + "] " + "Entry not exists. Try again.");
                    }
                    else {
                        // Entry exist
                        System.out.println("[" + System.currentTimeMillis() + "] " + "Entry value of " + entryKey + ":\t" + response);
                    }
                }
            }
            else if (cmd.equals("2")) {
                System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter the entry name: ");
                String entryKey = sc.nextLine();
                System.out.println("[" + System.currentTimeMillis() + "] " + "You are requesting the authority to edit the entry: " + entryKey + ". Checking...");
                boolean ableToEdit = stub.ableToEdit(entryKey, username);
                if (ableToEdit) {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "Authorized. You man now edit the entry.");
                    // TOD
                }
                else {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "This entry is currently being edited. Please try again later.");
                }
            }
            else if (cmd.equals("3")) {
                System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter the entry name: ");
                String entryKey = sc.nextLine();
                System.out.println("[" + System.currentTimeMillis() + "] " + "You are requesting to delete the entry: " + entryKey + ". Checking...");
                String response = stub.delete(entryKey);
                if (response.equals("Fail")) {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "Due to unknown reason, fail to delete the entry: " + entryKey + ". Please try again...");
                }
                else if (response.equals("Success")) {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "Successfully deleted the entry: " + entryKey);
                }
                else if (response.equals("No such key")) {
                    System.out.println("[" + System.currentTimeMillis() + "] " + "Key: ." + entryKey + " not found. Delete failed.");
                }
            }
            else if (cmd.equals("4")) {
                System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter the entry key: ");
                String entryKey = sc.nextLine();
                System.out.println("[" + System.currentTimeMillis() + "] " + "Please enter the entry value. Enter Q to end.");
                StringBuilder builder = new StringBuilder();
                while (true) {
                    String line = sc.nextLine();
                    if (line.equalsIgnoreCase("q")) break;
                    builder.append(line + "\n");
                }
                stub.put(entryKey, builder.toString());
                System.out.println("[" + System.currentTimeMillis() + "] " + "Adding new entry successful");
            }
            else {
                System.out.println("[" + System.currentTimeMillis() + "] " + "Unknown selection. Please choose from 1/2/3");
            }
        }
    }
}
