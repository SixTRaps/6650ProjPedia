import java.rmi.Remote;

public interface RemoteDevInterface extends Remote {
    /**
     * The method to ask whether the server is prepared for the data update.
     * @param update the new data to be updated on the server
     * @return server's response to the coordinator
     */
    boolean prepare(String update) throws Exception;

    /**
     * The method to commit the data update on the server.
     */
    void commit() throws Exception;

    /**
     * The method to abort the commit on the server.
     */
    void abort() throws Exception;

    /**
     * This method should be called by Server instance.
     * It informs the coordinator that there is a data update,
     * either put or delete operation.
     * @param port the port number of the Server
     * @param update the data upadate message
     * @return the coordinator response to the data update
     * @throws Exception possible exceptions
     */
    String hasDataUpdate(int port, String update) throws Exception;


    /**
     * Any server notify the coordinator via this function
     * @param action the action from the server
     * @param key the key from the server
     * @param value the value of the key from the server
     * @return 1 means succeed; 0 means fail
     * @throws Exception required exception for all RPC
     */
    public int coordinatorReceiveChange(String action, String key, String value) throws Exception;


    /**
     * Coordinator notify all the servers via this function
     * @param action the action to be done
     * @param key the key to be used
     * @param value the value to be used if any
     * @return 1 means succeed; 0 means fail
     * @throws Exception required exception for all RPC
     */
    public int otherServerReceiveChange(String action, String key, String value) throws Exception;

    /**
     * Coordinator let all the server commit the change
     * @return 1 means succeed; 0 means fail
     * @throws Exception required exception for all RPC
     */
    public int commitChange() throws Exception;

    void election() throws Exception;
}
