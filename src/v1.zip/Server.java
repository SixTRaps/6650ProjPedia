import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;


public class Server implements RemoteDevInterface, RemoteUserInterface {
    private static final Logger logger = LogManager.getLogger(Server.class);
    private static ConcurrentHashMap<String, String> store;
    private static int port;
    private static int coordPort;
    // role: 1 - Coordinator Server, 0 - Acceptor Server
    private int role;
    private String updateData = null;
    private String userAccountFileLocation = "./credential";
    private String dataFileLocation = "./data";

    private Map<String, SuserCredentials = new HashMap<>();
    static Server[] servers = new Server[5];

    // Jieren creates
//    private HashMap<String, String> userInfo = new HashMap<>();
    private Set<String> wiki = new HashSet<>();
    private boolean loginStatus = false;
    private String loginUser = "";
    private Server myCoordinator;
    private Server[] allServers;
    private Map<String, List<String>> pendingInfo = new HashMap<String, List<String>>();
    public int serverIndex;

    public Server(int port) {
        this.port = port;
        // TODO: load user crendential and data from local txt files

    }

    // Read all txt files from the credential folder.
    private void readUsersFromFolder(File folder) {
        File[] users = folder.listFiles();
        for (File user: users) {
            int length = user.getName().length();
            // Get the txt file name as username
            String username = user.getName().substring(0, length - 4);
            try {
                InputStreamReader reader = new InputStreamReader(new FileInputStream(user));
                BufferedReader br = new BufferedReader(reader);
                // Assume password is in one line
                String password = br.readLine();
                // Store username and password into the map
                userCredentials.put(username, password);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Read all txt files from the data folder
    private void readDataFromFolder(File folder) {
        File[] entries = folder.listFiles();
        for (File entry: entries) {
            int length = entry.getName().length();
            String entryKey = entry.getName().substring(0, length - 4);
            try {
                InputStreamReader reader = new InputStreamReader(new FileInputStream(entry));
                BufferedReader br = new BufferedReader(reader);
                StringBuilder info = new StringBuilder();
                String line = br.readLine();
                // Read all information for each entry
                while (line != null) {
                    info.append(line);
                }
                // Store the entry and the information into the map
                store.put(entryKey, info.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void createUserTxt(String username, String password, int port) {
        String path = "./credential/" + port;
        try
    }

    private void createDataTxt(String entry, String info, int port) {

    }

    private void deleteUserTxt(String username, int port) {

    }

    private void deleteDataTxt(String entry, int port) {

    }

    @Override
    public boolean prepare(String update) throws Exception {
        return false;
    }

    @Override
    public void commit() throws Exception {

    }

    @Override
    public void abort() throws Exception {

    }

    @Override
    public void election() {

    };

    @Override
    public String hasDataUpdate(int port, String update) throws Exception {
        return null;
    }

    @Override
    public ConcurrentHashMap.KeySetView<String, String> getEntryKeyList() {
        return store.keySet();
    }

    @Override
    public String put(String key, String value) throws Exception {
        logger.info("Putting " + key + " with value " + value + " into store");
        int notifyAndCommit = myCoordinator.coordinatorReceiveChange("put", key, value);
        if (notifyAndCommit == 0) {
            logger.error("Cannot notify the coordinator");
            return "Fail";
        }

    }


    /**
     * Any server notify the coordinator via this function
     * @param action the action from the server
     * @param key the key from the server
     * @param value the value of the key from the server
     * @return 1 means succeed; 0 means fail
     * @throws Exception required exception for all RPC
     */
    @Override
    public int coordinatorReceiveChange(String action, String key, String value) throws Exception {
        logger.info("Send " + action + " action to the coordinator");
        int times = 0;
        while (times < 10) {
            int count = 0;
            for (Server ser: allServers) {
                count += ser.otherServerReceiveChange(action, key, value);
            }
            if (count == 5) {
                int commitTimes = 0;
                while (commitTimes < 10) {
                    int commitCount = 0;
                    for (Server ser: allServers) {
                        commitCount += ser.commitChange();
                    }
                    if (commitCount == 5) {
                        return 1;
                    }
                    commitTimes++;
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            times++;
        }
        logger.error("Cannot notify all the servers");
        return 0;
    }



    /**
     * Coordinator notify all the servers via this function
     * @param action the action to be done
     * @param key the key to be used
     * @param value the value to be used if any
     * @return 1 means succeed; 0 means fail
     * @throws Exception required exception for all RPC
     */
    @Override
    public int otherServerReceiveChange(String action, String key, String value) throws Exception{
        if (this.pendingInfo.containsKey(key)) {
            logger.info("ACK: Server " + this.serverIndex + " has been acknowledged");
            return 1;
        } else {
            try {
                List<String> info = Arrays.asList(action, value);
                this.pendingInfo.put(key, info);
                logger.info("ACK: Server " + this.serverIndex + " has been acknowledged and added the new key " + key);
                return 1;
            } catch (Exception e) {
                e.printStackTrace();
                return 0;
            }
        }
    }


    /**
     * Coordinator let all the server commit the change
     * @return 1 means succeed; 0 means fail
     * @throws Exception required exception for all RPC
     */
    @Override
    public int commitChange() throws Exception{
        List<String> changed = new ArrayList<>();
        for (String pendingKey: this.pendingInfo.keySet()) {
            List<String> info = this.pendingInfo.get(pendingKey);
            if (info.get(0).equals("put")) {
                store.put(pendingKey, info.get(1));
                //Todo: put into txt
                logger.info("Go: Server " + this.serverIndex + " successfully put " + pendingKey +" in to the store");
                logger.info("Server " + + this.serverIndex + "'s store is" + this.wiki);
            } else {
                if (this.wiki.containsKey(pendingKey)) {
                    this.wiki.remove(pendingKey);
                }
                logger.info("Go: Server " + this.serverIndex + " successfully delete" + pendingKey +" in to the store");
                logger.info("Server " + + this.serverIndex + "'s store is" + this.wiki);
            }
            changed.add(pendingKey);
        }
        int i = 0;
        while (i < changed.size()) {
            this.pendingInfo.remove(changed.get(i));
            i++;
        }
        return 1;
    }




    @Override
    public String get(String key) throws Exception {
        if (wiki.contains(key)) {
            String wikiInfo = readFile(key);
            return wikiInfo;
        } else {
            return "None";
        }
    }

    @Override
    public String delete(String key) throws Exception {
        logger.info("Deleting " + key + " from store");
        int notifyAndCommit = myCoordinator.coordinatorReceiveChange("delete", k, "");
        if (notifyAndCommit == 0) {
            logger.error("Cannot notify the coordinator");
            return "Fail";
        }
        return "Success";
    }

    @Override
    public String login(String userName, String userPwd) throws Exception {
        if (loginStatus) {
            return "Already login as " + loginUser + ". Please logout first";
        } else {
            if (userCredentials.containsKey(userName) && userPwd.equals(userCredentials.get(userName))) {
                loginStatus = true;
                loginUser = userName;
                return "Login successfully";
            } else {
                return "Wrong username or password";
            }
        }

    }

    @Override
    public String signup(String userName, String userPwd) throws Exception {
        if (userInfo.containsKey(userName)) {
            return "User already exit. No need for register";
        } else {
            .put(userName, userPwd);
            updateDatabase();//Todo
            return "Sign up successfully";
        }



    }

    @Override
    public String logout(String userName) throws Exception {
        if (loginStatus) {
            loginStatus = false;
            return "Logout successfully";
        } else {
            return "You are not log in. Please register or login";
        }

    }

    public static void main(String[] args) {
        // TODO: service name:"PROJPEDIA"
        String[] list = new String[5];
        list[0] = "32000";
        list[1] = "32001";
        list[2] = "32002";
        list[3] = "32003";
        list[4] = "32004";
        for (int i = 0; i < list.length; i++) {
            try {
                port = Integer.parseInt(list[i]);
                servers[i] = new Server(port);
                RemoteUserInterface stub = (RemoteUserInterface) UnicastRemoteObject.exportObject(servers[i], port);
                Registry registry = LocateRegistry.createRegistry(port);
                registry.rebind("PROJPEDIA", stub);
                System.out.println(String.format("Server %s is running at port %s",
                        new String[]{Integer.toString(i), list[i]});
                File dataFolder = new File("./data/" + port);
                File userFolder = new File("./credential/" + port);
                servers[i].readUsersFromFolder(userFolder);
                System.out.println("Server " + i + " loaded all users information successfully");
                servers[i].readDataFromFolder(dataFolder);
                System.out.println("Server " + i + " loaded all entries with information successfully");
            } catch (Exception e) {
                System.err.println("Server exception: " + e.toString());
            }
        }
    }


}
